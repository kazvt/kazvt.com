﻿=== Legend of Zelda Cursor Set ===

By: Raythar

Download: http://www.rw-designer.com/cursor-set/legend-of-zelda

Author's description:

This is my own, custom made, cursor set for the legend of zelda, all hand drawn.

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.