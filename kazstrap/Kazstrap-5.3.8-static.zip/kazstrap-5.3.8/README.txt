Kazstrap 5.3.8 - static distribution
=====================================

Kazstrap is a retro-styled, drop-in Bootstrap 5.3.8 browser distribution. It
keeps Bootstrap classes and data-bs-* attributes. This archive contains only
compiled browser files; no Node.js, npm, CDN, or build step is required.

Quick start
-----------

1. Unzip this package and copy its dist folder into your site, for example:
   /vendor/kazstrap/dist/
2. Use Kazstrap in place of stock Bootstrap CSS:

   <link rel="stylesheet" href="/vendor/kazstrap/dist/css/bootstrap.min.css">

   For debugging with readable CSS, use bootstrap.css instead. For a right-to-
   left site, use bootstrap.rtl.min.css instead of bootstrap.min.css.
3. Add the browser JavaScript before </body> when you use interactive
   components such as the navbar toggle, dropdowns, modals, tabs, or tooltips:

   <script src="/vendor/kazstrap/dist/js/bootstrap.bundle.min.js"></script>

The bundle includes Popper. Existing Bootstrap markup continues to work. Do not
load stock Bootstrap CSS alongside Kazstrap; load your own site CSS after
Kazstrap when you want to override its theme.

For the full theme and embedded fsTahoma8px font, use the full build shown
above. The font is embedded in that stylesheet, so there is no separate font
file to copy. Emoji fallbacks are retained. If your Content Security Policy
blocks data: fonts, allow data: in font-src or host the supplied font separately.

Font credit and license
-----------------------

fs Tahoma 8px by ETHproductions, Copyright 2012. The FontStruct source lists
this font under Creative Commons Attribution Share Alike 3.0 (CC BY-SA 3.0).
The supplied WOFF2 is embedded unchanged in the CSS. Source:
https://fontstruct.com/fontstructions/show/735108/fs_tahoma_8px
License: https://creativecommons.org/licenses/by-sa/3.0/

Optional color mode: add data-bs-theme="dark" to <html> or a parent element to
apply Kazstrap's dark semantic colors. Removing it restores the default light
mode.

Files
-----

dist/css/  Full, RTL, grid-only, reboot-only, and utilities-only CSS builds.
           The ZIP omits unlinked CSS source maps, which describe the upstream
           Bootstrap output and do not include Kazstrap's stylesheet changes.
           bootstrap.min.css is the complete recommended theme; bootstrap-grid
           contains only the layout grid.
dist/js/   Browser JavaScript builds and their source maps. Use
           bootstrap.bundle.min.js for script tags; it includes Popper.
LICENSE    Upstream Bootstrap MIT license notice.