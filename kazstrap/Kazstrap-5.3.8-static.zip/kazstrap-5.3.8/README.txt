Kazstrap 5.3.8 - static distribution
=====================================

Kazstrap is a retro-styled, drop-in Bootstrap 5.3.8 browser distribution. It
keeps Bootstrap classes and data-bs-* attributes. This archive contains only
compiled browser files; no Node.js, npm, CDN, or build step is required.

Quick start
-----------

1. Unzip this package and copy its dist folder into your site, for example:
   /vendor/kazstrap/dist/
2. Use Kazstrap in place of stock Bootstrap CSS:

   <link rel="stylesheet" href="/vendor/kazstrap/dist/css/bootstrap.min.css">

3. Add the browser JavaScript before </body> when you use interactive
   components such as the navbar toggle, dropdowns, modals, tabs, or tooltips:

   <script src="/vendor/kazstrap/dist/js/bootstrap.bundle.min.js"></script>

The bundle includes Popper. Existing Bootstrap markup continues to work. Do not
load stock Bootstrap CSS alongside Kazstrap; load your own site CSS after
Kazstrap when you want to override its theme.

For the full theme and the embedded fsTahoma8px font, use the full build shown
above. The font is embedded in that stylesheet, so there is no separate font
file to copy. Emoji fallbacks are retained. If your Content Security Policy
blocks data: fonts, allow data: in font-src or host the supplied font separately.

Optional color mode: add data-bs-theme="dark" to <html> or a parent element to
apply Kazstrap's dark semantic colors. Removing it restores the default light
mode.

Files
-----

dist/css/  Full, RTL, grid-only, reboot-only, and utilities-only CSS builds
           with source maps. bootstrap.min.css is the complete, recommended
           theme build; bootstrap-grid is only the layout grid.
dist/js/   Browser JavaScript builds. bootstrap.bundle.min.js is recommended
           for script-tag use and includes Popper.
LICENSE    MIT license notice for the upstream Bootstrap distribution.