Kazstrap 5.3.8 - static distribution
=====================================

Kazstrap is a drop-in, retro-styled Bootstrap 5.3.8 distribution. It uses the
usual Bootstrap classes and data attributes. This archive contains compiled
browser files only; no Node.js, npm, or build step is required.

Quick start
-----------

1. Copy the dist folder into your site, for example: /vendor/kazstrap/dist/
2. Replace your Bootstrap stylesheet link with:

   <link rel="stylesheet" href="/vendor/kazstrap/dist/css/bootstrap.min.css">

3. Before </body>, include the bundled browser JavaScript if your page uses
   Bootstrap interactive components such as the navbar toggle, dropdowns,
   modals, tabs, or tooltips:

   <script src="/vendor/kazstrap/dist/js/bootstrap.bundle.min.js"></script>

The bundle includes Popper. Existing Bootstrap 5 classes and data-bs-* markup
continue to work. Use Kazstrap's stylesheet in place of stock Bootstrap CSS;
load your own site stylesheet after it when you want to override Kazstrap.

The CSS includes the fsTahoma8px font data inline, so there is no separate font
file to copy. The usual color emoji fallbacks are retained. If your Content
Security Policy blocks data: fonts, allow data: in font-src or switch to a
separately hosted font file.

Files
-----

dist/css/  Full, RTL, grid-only, reboot-only, utilities-only CSS builds and
           their source maps. bootstrap.min.css is the normal full build.
dist/js/   Browser JavaScript builds. bootstrap.bundle.min.js is recommended
           for standard script-tag use; it includes Popper.
LICENSE    MIT license notice for the upstream Bootstrap distribution.